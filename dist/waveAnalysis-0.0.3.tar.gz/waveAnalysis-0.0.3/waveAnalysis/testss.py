import mainView
app=wx.App()
frame=baseView()
frame.Show(True)
app.MainLoop()