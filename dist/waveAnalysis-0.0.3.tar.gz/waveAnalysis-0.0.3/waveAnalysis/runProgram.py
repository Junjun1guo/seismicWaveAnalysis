"""
python 2.7
"""
import wx
from mainView import *
####################################

app=wx.App()
frame=baseView()
frame.Show(True)
app.MainLoop()



